import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TestService {

  constructor() { }

  myArray = [
    {
      heading: 'Testing 1',
      text: 'text data 1'
    },
    {
      heading: 'Testing 2',
      text: 'text data 2'
    },
    {
      heading: 'Testing 3',
      text: 'text data 3'
    },
    {
      heading: 'Testing 4',
      text: 'text data 4'
    },
  ]
  getArrayData() {
    return this.myArray;
  }
}
